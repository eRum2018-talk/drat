[![codecov](https://codecov.io/gh/theoroe3/MyFirstPackage/branch/master/graph/badge.svg)](https://codecov.io/gh/theoroe3/MyFirstPackage) [![Build Status](https://travis-ci.org/theoroe3/MyFirstPackage.svg?branch=master)](https://travis-ci.org/theoroe3/MyFirstPackage) [![AppVeyor Build Status](https://ci.appveyor.com/api/projects/status/github/theoroe3/MyFirstPackage?branch=master&svg=true)](https://ci.appveyor.com/project/theoroe3/MyFirstPackage)

# MyFirstPackage
My First Package

